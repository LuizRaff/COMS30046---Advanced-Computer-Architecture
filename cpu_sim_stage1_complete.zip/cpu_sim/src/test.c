#include <stdio.h>
#include "core/regfile.h"
#include "isa/exec.h"

int main(void) {
    return 0;
}
