#ifndef CORE_TYPES_H
#define CORE_TYPES_H

#include <stdint.h>
#include <stdbool.h>

typedef int32_t word_t;

enum { NUM_REGS = 32 };

#endif // CORE_TYPES_H