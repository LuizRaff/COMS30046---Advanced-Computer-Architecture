#include "cpu.h"
#include "../isa/exec.h"
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <string.h>

/* Helper missing functions here to compile logic check.. */
int main(){return 0;}
